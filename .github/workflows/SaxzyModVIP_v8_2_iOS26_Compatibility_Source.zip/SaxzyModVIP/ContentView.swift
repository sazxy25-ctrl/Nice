import SwiftUI
import UniformTypeIdentifiers
import UIKit

@main
struct SaxzyModVIPApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

enum AppTab: Int, CaseIterable {
    case home = 0
    case files = 1
    case patches = 2
    case cleaner = 3
    case appData = 4
}

struct SharedFile: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

struct ContentView: View {
    @AppStorage("saxzy_onboarded_v7") private var hasCompletedOnboarding = false
    @AppStorage("saxzy_password_configured") private var passwordConfigured = false
    @State private var isUnlocked = false
    @AppStorage("saxzy_lang") private var selectedLangRaw = AppLanguage.khmer.rawValue
    @AppStorage("saxzy_show_cleaner") private var showCleanerTab = true

    @State private var selectedTab: AppTab = .home
    @State private var hasAutoOpenedTelegram = false
    @State private var files: [URL] = []
    @State private var searchFiles = ""
    @State private var searchPatches = ""
    @State private var showingImporter = false
    @State private var showingSettings = false
    @State private var showingLogs = false
    @State private var previewingFile: SharedFile?
    @State private var logs: [String] = []

    // Cleaner state
    @State private var isScanning = false
    @State private var cacheBytes: Int64 = 0
    @State private var freeSpaceBytes: Int64 = 0
    @State private var cleanStatus = ""

    private let telegramURL = URL(string: "https://t.me/mgthegod68")!

    private var lang: AppLanguage {
        AppLanguage(rawValue: selectedLangRaw) ?? .khmer
    }

    private var l: L10n { L10n(lang: lang) }

    private var storageDirectory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let folder = docs.appendingPathComponent("SaxzyVault", isDirectory: true)
        if !FileManager.default.fileExists(atPath: folder.path) {
            try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        }
        return folder
    }

    private var filteredFiles: [URL] {
        let q = searchFiles.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return files }
        return files.filter { $0.lastPathComponent.localizedCaseInsensitiveContains(q) }
    }

    private var patchFiles: [URL] {
        let onlyPatches = files.filter { $0.pathExtension.lowercased() == "3105" }
        let q = searchPatches.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return onlyPatches }
        return onlyPatches.filter { $0.lastPathComponent.localizedCaseInsensitiveContains(q) }
    }

    var body: some View {
        ZStack {
            if !hasCompletedOnboarding {
                OnboardingView(selectedLangRaw: $selectedLangRaw) {
                    hasCompletedOnboarding = true
                    addLog("Onboarding completed (lang=\(selectedLangRaw))")
                }
            } else if !passwordConfigured || !isUnlocked {
                PasswordGateView(isSetup: !passwordConfigured) {
                    passwordConfigured = true
                    isUnlocked = true
                }
            } else {
                mainShell
            }
        }
        .preferredColorScheme(.light)
        .onAppear {
            loadStoredFiles()
            refreshDeviceStats()
            addLog("Saxzy Mod VIP v7 launched · Mg The God")
            // Auto-open Telegram channel once immediately on app launch
            if !hasAutoOpenedTelegram {
                hasAutoOpenedTelegram = true
                addLog("Auto-opening Telegram: https://t.me/mgthegod68")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    UIApplication.shared.open(telegramURL)
                }
            }
        }
        .onOpenURL { url in
            importExternalURL(url)
        }
        .fileImporter(
            isPresented: $showingImporter,
            allowedContentTypes: [.data, .item],
            allowsMultipleSelection: true
        ) { result in
            handleImport(result)
        }
        .fullScreenCover(item: $previewingFile) { item in
            FilePreviewView(url: item.url, lang: lang)
        }
        .sheet(isPresented: $showingSettings) {
            settingsSheet
        }
        .sheet(isPresented: $showingLogs) {
            logsSheet
        }
    }

    // MARK: - Main Shell with Floating Pill Tab Bar (3105 Style)
    private var mainShell: some View {
        ZStack(alignment: .bottom) {
            ThemeStyle.bg.ignoresSafeArea()

            VStack(spacing: 0) {
                switch selectedTab {
                case .home:
                    homeTab
                case .files:
                    filesTab
                case .patches:
                    patchesTab
                case .cleaner:
                    cleanerTab
                case .appData:
                    AppDataManagerView(isKhmer: lang == .khmer)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(.bottom, 76)

            floatingTabBar
        }
    }

    private var floatingTabBar: some View {
        HStack(spacing: 4) {
            tabButton(tab: .home, icon: "house.fill", title: l.tabHome)
            tabButton(tab: .files, icon: "folder.fill", title: l.tabFiles)
            tabButton(tab: .patches, icon: "shippingbox.fill", title: l.tabPatches)
            tabButton(tab: .appData, icon: "externaldrive.fill", title: lang == .khmer ? "ទិន្នន័យ App" : "App Data")
            if showCleanerTab {
                tabButton(tab: .cleaner, icon: "sparkles", title: l.tabCleaner)
            }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 6)
        .background(Color.white)
        .clipShape(Capsule())
        .overlay(Capsule().stroke(ThemeStyle.border, lineWidth: 1))
        .shadow(color: Color.black.opacity(0.08), radius: 14, y: 4)
        .padding(.horizontal, 20)
        .padding(.bottom, 10)
    }

    private func tabButton(tab: AppTab, icon: String, title: String) -> some View {
        let isActive = selectedTab == tab
        return Button {
            withAnimation(.easeInOut(duration: 0.18)) {
                selectedTab = tab
            }
        } label: {
            VStack(spacing: 3) {
                Image(systemName: icon)
                    .font(.system(size: 16, weight: .semibold))
                Text(title)
                    .font(.system(size: 10, weight: .semibold))
                    .lineLimit(1)
            }
            .foregroundColor(isActive ? ThemeStyle.accent : ThemeStyle.textPrimary.opacity(0.75))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .background(isActive ? ThemeStyle.accentSoft : Color.clear)
            .clipShape(Capsule())
        }
    }

    // MARK: - Tab 1: Home (3105 Device + Features Layout)
    private var homeTab: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                // Top bar with brand + Logs & Settings icons
                HStack(spacing: 10) {
                    Image("LaunchLogo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 36, height: 36)
                        .clipShape(RoundedRectangle(cornerRadius: 10))

                    VStack(alignment: .leading, spacing: 1) {
                        Text("Saxzy Mod VIP")
                            .font(.headline.bold())
                            .foregroundColor(ThemeStyle.textPrimary)
                        Text("Mg The God · @mgthegod68")
                            .font(.caption2.bold())
                            .foregroundColor(ThemeStyle.accent)
                    }

                    Spacer()

                    Button {
                        showingLogs = true
                    } label: {
                        Image(systemName: "terminal")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(ThemeStyle.accent)
                            .frame(width: 38, height: 38)
                            .background(Color.white)
                            .clipShape(Circle())
                            .shadow(color: Color.black.opacity(0.05), radius: 4, y: 2)
                    }

                    Button {
                        showingSettings = true
                    } label: {
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(ThemeStyle.accent)
                            .frame(width: 38, height: 38)
                            .background(Color.white)
                            .clipShape(Circle())
                            .shadow(color: Color.black.opacity(0.05), radius: 4, y: 2)
                    }
                }
                .padding(.top, 8)

                // Device Section
                VStack(alignment: .leading, spacing: 8) {
                    Text(l.deviceSection)
                        .font(.subheadline.bold())
                        .foregroundColor(ThemeStyle.textSecondary)
                        .padding(.leading, 4)

                    VStack(spacing: 0) {
                        infoRow(title: l.hardwareModel, value: deviceIdentifier(), isMono: true)
                        Divider().padding(.leading, 16)
                        infoRow(title: l.iosVersion, value: UIDevice.current.systemVersion, isMono: true)
                        Divider().padding(.leading, 16)
                        infoRow(title: l.storageFree, value: ByteCountFormatter.string(fromByteCount: freeSpaceBytes, countStyle: .file), isMono: false)
                        Divider().padding(.leading, 16)
                        HStack {
                            Text(l.compatibility)
                                .font(.subheadline)
                                .foregroundColor(ThemeStyle.textPrimary)
                            Spacer()
                            Text(l.supported)
                                .font(.subheadline.bold())
                                .foregroundColor(ThemeStyle.supportedGreen)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 14)
                    }
                    .background(ThemeStyle.card)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(ThemeStyle.border, lineWidth: 1))
                }

                // Features Section
                VStack(alignment: .leading, spacing: 8) {
                    Text(l.featuresSection)
                        .font(.subheadline.bold())
                        .foregroundColor(ThemeStyle.textSecondary)
                        .padding(.leading, 4)

                    VStack(spacing: 0) {
                        HStack(spacing: 12) {
                            Image(systemName: "sparkles")
                                .font(.system(size: 18))
                                .foregroundColor(ThemeStyle.accent)
                                .frame(width: 28)
                            Text(l.tabCleaner)
                                .font(.subheadline.weight(.medium))
                                .foregroundColor(ThemeStyle.textPrimary)
                            Spacer()
                            Toggle("", isOn: $showCleanerTab)
                                .labelsHidden()
                                .tint(ThemeStyle.accent)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                    }
                    .background(ThemeStyle.card)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(ThemeStyle.border, lineWidth: 1))

                    Text(l.featuresHint)
                        .font(.caption)
                        .foregroundColor(ThemeStyle.textSecondary)
                        .padding(.leading, 4)
                }

                // Telegram Quick Card
                Button {
                    UIApplication.shared.open(telegramURL)
                } label: {
                    HStack(spacing: 12) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 12)
                                .fill(ThemeStyle.accentSoft)
                                .frame(width: 42, height: 42)
                            Image(systemName: "paperplane.fill")
                                .foregroundColor(ThemeStyle.accent)
                        }
                        VStack(alignment: .leading, spacing: 2) {
                            Text(l.telegramChannel)
                                .font(.subheadline.bold())
                                .foregroundColor(ThemeStyle.textPrimary)
                            Text("https://t.me/mgthegod68")
                                .font(.caption)
                                .foregroundColor(ThemeStyle.accent)
                        }
                        Spacer()
                        Image(systemName: "arrow.up.right")
                            .font(.caption.bold())
                            .foregroundColor(ThemeStyle.textSecondary)
                    }
                    .padding(14)
                    .background(ThemeStyle.card)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(ThemeStyle.border, lineWidth: 1))
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 20)
        }
    }

    private func infoRow(title: String, value: String, isMono: Bool) -> some View {
        HStack {
            Text(title)
                .font(.subheadline)
                .foregroundColor(ThemeStyle.textPrimary)
            Spacer()
            Text(value)
                .font(isMono ? .system(size: 14, design: .monospaced) : .subheadline)
                .foregroundColor(ThemeStyle.textSecondary)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
    }

    // MARK: - Tab 2: Files (3105 Workspace Style)
    private var filesTab: some View {
        VStack(spacing: 12) {
            // Top Header
            HStack {
                Spacer()
                Text(l.filesHeader)
                    .font(.headline.bold())
                    .foregroundColor(ThemeStyle.textPrimary)
                Spacer()
            }
            .overlay(alignment: .trailing) {
                Button {
                    showingImporter = true
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(ThemeStyle.accent)
                        .frame(width: 36, height: 36)
                        .background(Color.white)
                        .clipShape(Circle())
                        .shadow(color: Color.black.opacity(0.05), radius: 4, y: 2)
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 10)

            // Search Bar
            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(ThemeStyle.textSecondary)
                TextField(l.searchFiles, text: $searchFiles)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                if !searchFiles.isEmpty {
                    Button { searchFiles = "" } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(ThemeStyle.textSecondary)
                    }
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color.black.opacity(0.05))
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .padding(.horizontal, 16)

            // Workspace Header Card
            VStack(alignment: .leading, spacing: 8) {
                Text(l.workspaceTitle)
                    .font(.caption.bold())
                    .foregroundColor(ThemeStyle.textSecondary)
                    .padding(.leading, 4)

                HStack(spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 12)
                            .fill(ThemeStyle.accentSoft)
                            .frame(width: 40, height: 40)
                        Image(systemName: "folder.fill")
                            .foregroundColor(ThemeStyle.accent)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Saxzy Mod VIP")
                            .font(.subheadline.bold())
                            .foregroundColor(ThemeStyle.textPrimary)
                        Text(l.workspaceSub)
                            .font(.caption)
                            .foregroundColor(ThemeStyle.textSecondary)
                    }
                    Spacer()
                    Text("\(files.count)")
                        .font(.caption.bold())
                        .foregroundColor(ThemeStyle.accent)
                        .padding(.horizontal, 9)
                        .padding(.vertical, 4)
                        .background(ThemeStyle.accentSoft)
                        .clipShape(Capsule())
                }
                .padding(14)
                .background(ThemeStyle.card)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(ThemeStyle.border, lineWidth: 1))
            }
            .padding(.horizontal, 16)

            // File List
            if filteredFiles.isEmpty {
                Spacer()
                VStack(spacing: 10) {
                    Image(systemName: "folder")
                        .font(.system(size: 38))
                        .foregroundColor(ThemeStyle.accent.opacity(0.7))
                    Text(l.noFilesYet)
                        .font(.subheadline.bold())
                        .foregroundColor(ThemeStyle.textPrimary)
                    Text(l.importHint)
                        .font(.caption)
                        .foregroundColor(ThemeStyle.textSecondary)
                }
                Spacer()
            } else {
                List {
                    ForEach(filteredFiles, id: \.self) { url in
                        Button {
                            previewingFile = SharedFile(url: url)
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: iconName(for: url))
                                    .font(.system(size: 18))
                                    .foregroundColor(ThemeStyle.accent)
                                    .frame(width: 36, height: 36)
                                    .background(ThemeStyle.accentSoft)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))

                                VStack(alignment: .leading, spacing: 2) {
                                    Text(url.lastPathComponent)
                                        .font(.subheadline.weight(.semibold))
                                        .foregroundColor(ThemeStyle.textPrimary)
                                        .lineLimit(1)
                                    Text("\(url.pathExtension.isEmpty ? "FILE" : url.pathExtension.uppercased()) · \(formattedFileSize(for: url))")
                                        .font(.caption2)
                                        .foregroundColor(ThemeStyle.textSecondary)
                                }
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.caption)
                                    .foregroundColor(ThemeStyle.textSecondary.opacity(0.6))
                            }
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .listRowBackground(
                            RoundedRectangle(cornerRadius: 14)
                                .fill(Color.white)
                                .overlay(RoundedRectangle(cornerRadius: 14).stroke(ThemeStyle.border, lineWidth: 1))
                                .padding(.vertical, 3)
                        )
                        .listRowSeparator(.hidden)
                    }
                    .onDelete(perform: deleteFromFilteredFiles)
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
                .padding(.horizontal, 8)
            }
        }
    }

    // MARK: - Tab 3: Patches (3105 Patches Screen Style)
    private var patchesTab: some View {
        VStack(spacing: 12) {
            HStack {
                Spacer()
                Text(l.patchesHeader)
                    .font(.headline.bold())
                    .foregroundColor(ThemeStyle.textPrimary)
                Spacer()
            }
            .overlay(alignment: .trailing) {
                Button {
                    showingImporter = true
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(ThemeStyle.accent)
                        .frame(width: 36, height: 36)
                        .background(Color.white)
                        .clipShape(Circle())
                        .shadow(color: Color.black.opacity(0.05), radius: 4, y: 2)
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 10)

            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(ThemeStyle.textSecondary)
                TextField(l.searchPatches, text: $searchPatches)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color.black.opacity(0.05))
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .padding(.horizontal, 16)

            if patchFiles.isEmpty {
                VStack(spacing: 14) {
                    Image(systemName: "shippingbox")
                        .font(.system(size: 36))
                        .foregroundColor(ThemeStyle.accent)
                    Text(l.noPatchesTitle)
                        .font(.headline.bold())
                        .foregroundColor(ThemeStyle.textPrimary)
                    Text(l.noPatchesDesc)
                        .font(.caption)
                        .foregroundColor(ThemeStyle.textSecondary)
                        .multilineTextAlignment(.center)
                    Button {
                        showingImporter = true
                    } label: {
                        Text(l.newPatch)
                            .font(.subheadline.bold())
                            .foregroundColor(ThemeStyle.accent)
                            .padding(.horizontal, 22)
                            .padding(.vertical, 10)
                            .background(ThemeStyle.accentSoft)
                            .clipShape(Capsule())
                    }
                    .padding(.top, 4)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 48)
                .padding(.horizontal, 20)
                .background(ThemeStyle.card)
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(ThemeStyle.border, lineWidth: 1))
                .padding(.horizontal, 16)
                .padding(.top, 6)

                Spacer()
            } else {
                List {
                    ForEach(patchFiles, id: \.self) { url in
                        Button {
                            previewingFile = SharedFile(url: url)
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "shippingbox.fill")
                                    .font(.system(size: 18))
                                    .foregroundColor(ThemeStyle.accent)
                                    .frame(width: 38, height: 38)
                                    .background(ThemeStyle.accentSoft)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))

                                VStack(alignment: .leading, spacing: 2) {
                                    Text(url.deletingPathExtension().lastPathComponent)
                                        .font(.subheadline.bold())
                                        .foregroundColor(ThemeStyle.textPrimary)
                                        .lineLimit(1)
                                    Text(".3105 · \(formattedFileSize(for: url))")
                                        .font(.caption2)
                                        .foregroundColor(ThemeStyle.textSecondary)
                                }
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.caption)
                                    .foregroundColor(ThemeStyle.textSecondary.opacity(0.6))
                            }
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .listRowBackground(
                            RoundedRectangle(cornerRadius: 14)
                                .fill(Color.white)
                                .overlay(RoundedRectangle(cornerRadius: 14).stroke(ThemeStyle.border, lineWidth: 1))
                                .padding(.vertical, 3)
                        )
                        .listRowSeparator(.hidden)
                    }
                    .onDelete(perform: deleteFromPatches)
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
                .padding(.horizontal, 8)
            }
        }
    }

    // MARK: - Tab 4: Cleaner (3105 Cleaner Card Style)
    private var cleanerTab: some View {
        VStack(spacing: 16) {
            HStack {
                Spacer()
                Text(l.cleanerHeader)
                    .font(.headline.bold())
                    .foregroundColor(ThemeStyle.textPrimary)
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.top, 10)

            VStack(spacing: 16) {
                if isScanning {
                    ProgressView()
                        .tint(ThemeStyle.accent)
                        .scaleEffect(1.3)
                        .padding(.top, 8)
                    Text(l.scanningCache)
                        .font(.subheadline.bold())
                        .foregroundColor(ThemeStyle.textPrimary)
                } else {
                    Image(systemName: "sparkles")
                        .font(.system(size: 34))
                        .foregroundColor(ThemeStyle.accent)
                    Text(cleanStatus.isEmpty ? l.readyToClean : cleanStatus)
                        .font(.subheadline.bold())
                        .foregroundColor(ThemeStyle.textPrimary)
                        .multilineTextAlignment(.center)
                    Text("\(l.cacheFound): \(ByteCountFormatter.string(fromByteCount: cacheBytes, countStyle: .file))")
                        .font(.caption)
                        .foregroundColor(ThemeStyle.textSecondary)

                    Button(action: runClean) {
                        Text(l.cleanNow)
                            .font(.subheadline.bold())
                            .foregroundColor(.white)
                            .padding(.horizontal, 26)
                            .padding(.vertical, 11)
                            .background(ThemeStyle.accent)
                            .clipShape(Capsule())
                    }
                    .padding(.top, 4)
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 36)
            .padding(.horizontal, 20)
            .background(ThemeStyle.card)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(ThemeStyle.border, lineWidth: 1))
            .padding(.horizontal, 16)

            Spacer()
        }
        .onAppear {
            refreshDeviceStats()
        }
    }

    // MARK: - Settings Sheet (3105 Settings Style)
    private var settingsSheet: some View {
        NavigationStack {
            ZStack {
                ThemeStyle.bg.ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        // Brand Card
                        HStack(spacing: 14) {
                            Image("LaunchLogo")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 52, height: 52)
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Saxzy Mod VIP")
                                    .font(.headline.bold())
                                    .foregroundColor(ThemeStyle.textPrimary)
                                Text("Version 7.0 · Mg The God")
                                    .font(.caption)
                                    .foregroundColor(ThemeStyle.textSecondary)
                            }
                            Spacer()
                        }
                        .padding(14)
                        .background(ThemeStyle.card)
                        .clipShape(RoundedRectangle(cornerRadius: 16))

                        // Language Switcher
                        VStack(alignment: .leading, spacing: 8) {
                            Text(l.languageTitle)
                                .font(.caption.bold())
                                .foregroundColor(ThemeStyle.textSecondary)
                                .padding(.leading, 4)

                            HStack(spacing: 8) {
                                ForEach(AppLanguage.allCases) { option in
                                    let active = option == lang
                                    Button {
                                        selectedLangRaw = option.rawValue
                                        addLog("Language switched to \(option.displayName)")
                                    } label: {
                                        Text(option.displayName)
                                            .font(.subheadline.bold())
                                            .foregroundColor(active ? ThemeStyle.accent : ThemeStyle.textPrimary)
                                            .frame(maxWidth: .infinity)
                                            .padding(.vertical, 10)
                                            .background(active ? ThemeStyle.accentSoft : Color.clear)
                                            .clipShape(Capsule())
                                    }
                                }
                            }
                            .padding(6)
                            .background(ThemeStyle.card)
                            .clipShape(Capsule())
                        }

                        // Social Media (Telegram)
                        VStack(alignment: .leading, spacing: 8) {
                            Text(l.socialMedia)
                                .font(.caption.bold())
                                .foregroundColor(ThemeStyle.textSecondary)
                                .padding(.leading, 4)

                            Button {
                                UIApplication.shared.open(telegramURL)
                            } label: {
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(l.telegramChannel)
                                            .font(.subheadline.bold())
                                            .foregroundColor(ThemeStyle.accent)
                                        Text(l.telegramSub)
                                            .font(.caption)
                                            .foregroundColor(ThemeStyle.textSecondary)
                                    }
                                    Spacer()
                                    Image(systemName: "arrow.up.right")
                                        .font(.caption.bold())
                                        .foregroundColor(ThemeStyle.accent)
                                }
                                .padding(16)
                                .background(ThemeStyle.card)
                                .clipShape(RoundedRectangle(cornerRadius: 16))
                            }
                        }

                        // Credits
                        VStack(alignment: .leading, spacing: 8) {
                            Text(l.credits)
                                .font(.caption.bold())
                                .foregroundColor(ThemeStyle.textSecondary)
                                .padding(.leading, 4)

                            Button {
                                UIApplication.shared.open(telegramURL)
                            } label: {
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Mg The God")
                                            .font(.subheadline.bold())
                                            .foregroundColor(ThemeStyle.accent)
                                        Text(l.developerRole)
                                            .font(.caption)
                                            .foregroundColor(ThemeStyle.textSecondary)
                                    }
                                    Spacer()
                                    Image(systemName: "arrow.up.right")
                                        .font(.caption.bold())
                                        .foregroundColor(ThemeStyle.accent)
                                }
                                .padding(16)
                                .background(ThemeStyle.card)
                                .clipShape(RoundedRectangle(cornerRadius: 16))
                            }
                        }
                    }
                    .padding(16)
                }
            }
            .navigationTitle(l.settingsTitle)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(l.done) {
                        showingSettings = false
                    }
                    .font(.subheadline.bold())
                    .foregroundColor(ThemeStyle.accent)
                }
            }
        }
        .preferredColorScheme(.light)
    }

    // MARK: - Session Logs Sheet
    private var logsSheet: some View {
        NavigationStack {
            ZStack {
                ThemeStyle.bg.ignoresSafeArea()
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 6) {
                        ForEach(Array(logs.enumerated()), id: \.offset) { _, line in
                            Text(line)
                                .font(.system(size: 12, design: .monospaced))
                                .foregroundColor(ThemeStyle.textPrimary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    .padding(16)
                }
            }
            .navigationTitle(l.sessionLogs)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(l.clear) {
                        logs.removeAll()
                    }
                    .foregroundColor(ThemeStyle.accent)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button(l.done) {
                        showingLogs = false
                    }
                    .font(.subheadline.bold())
                    .foregroundColor(ThemeStyle.accent)
                }
            }
        }
        .preferredColorScheme(.light)
    }

    // MARK: - Helpers
    private func addLog(_ msg: String) {
        let df = DateFormatter()
        df.dateFormat = "HH:mm:ss"
        logs.append("[\(df.string(from: Date()))] [Saxzy] \(msg)")
    }

    private func loadStoredFiles() {
        let contents = (try? FileManager.default.contentsOfDirectory(
            at: storageDirectory,
            includingPropertiesForKeys: [.creationDateKey],
            options: [.skipsHiddenFiles]
        )) ?? []
        files = contents.sorted { $0.lastPathComponent.lowercased() < $1.lastPathComponent.lowercased() }
    }

    private func importExternalURL(_ url: URL) {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let dest = storageDirectory.appendingPathComponent(url.lastPathComponent)
        do {
            if FileManager.default.fileExists(atPath: dest.path) {
                try FileManager.default.removeItem(at: dest)
            }
            try FileManager.default.copyItem(at: url, to: dest)
            loadStoredFiles()
            addLog("Imported: \(url.lastPathComponent)")
        } catch {
            addLog("Import failed: \(error.localizedDescription)")
        }
    }

    private func handleImport(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            for url in urls {
                importExternalURL(url)
            }
        case .failure(let error):
            addLog("Picker error: \(error.localizedDescription)")
        }
    }

    private func deleteFromFilteredFiles(at offsets: IndexSet) {
        let targets = offsets.map { filteredFiles[$0] }
        for url in targets {
            try? FileManager.default.removeItem(at: url)
            addLog("Deleted: \(url.lastPathComponent)")
        }
        loadStoredFiles()
    }

    private func deleteFromPatches(at offsets: IndexSet) {
        let targets = offsets.map { patchFiles[$0] }
        for url in targets {
            try? FileManager.default.removeItem(at: url)
            addLog("Deleted patch: \(url.lastPathComponent)")
        }
        loadStoredFiles()
    }

    private func refreshDeviceStats() {
        if let attrs = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory()) {
            freeSpaceBytes = (attrs[.systemFreeSize] as? NSNumber)?.int64Value ?? 0
        }
        cacheBytes = calculateCacheSize()
    }

    private func calculateCacheSize() -> Int64 {
        var total: Int64 = 0
        let fm = FileManager.default
        let dirs = [fm.temporaryDirectory] + fm.urls(for: .cachesDirectory, in: .userDomainMask)
        for dir in dirs {
            if let en = fm.enumerator(at: dir, includingPropertiesForKeys: [.fileSizeKey]) {
                for case let f as URL in en {
                    if let s = try? f.resourceValues(forKeys: [.fileSizeKey]).fileSize {
                        total += Int64(s)
                    }
                }
            }
        }
        return total
    }

    private func runClean() {
        isScanning = true
        addLog("Started cache scan...")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
            let before = calculateCacheSize()
            let fm = FileManager.default
            for dir in [fm.temporaryDirectory] + fm.urls(for: .cachesDirectory, in: .userDomainMask) {
                if let items = try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil) {
                    for item in items { try? fm.removeItem(at: item) }
                }
            }
            refreshDeviceStats()
            let freed = max(0, before - cacheBytes)
            let str = ByteCountFormatter.string(fromByteCount: freed, countStyle: .file)
            cleanStatus = lang == .khmer ? "សម្អាតរួចរាល់ · បានលុប \(str)" : "Clean complete · Freed \(str)"
            addLog("Cleaned \(str)")
            isScanning = false
        }
    }

    private func deviceIdentifier() -> String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let id = machineMirror.children.reduce("") { acc, element in
            guard let value = element.value as? Int8, value != 0 else { return acc }
            return acc + String(UnicodeScalar(UInt8(value)))
        }
        return id.isEmpty ? UIDevice.current.model : id
    }

    private func iconName(for url: URL) -> String {
        switch url.pathExtension.lowercased() {
        case "3105": return "shippingbox.fill"
        case "zip", "rar", "7z", "ipa": return "archivebox.fill"
        case "png", "jpg", "jpeg", "heic": return "photo.fill"
        default: return "doc.fill"
        }
    }

    private func formattedFileSize(for url: URL) -> String {
        let values = try? url.resourceValues(forKeys: [.fileSizeKey])
        guard let bytes = values?.fileSize else { return "—" }
        return ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
    }
}
