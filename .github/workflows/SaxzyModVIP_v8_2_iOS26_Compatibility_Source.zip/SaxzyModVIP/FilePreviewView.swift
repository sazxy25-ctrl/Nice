import SwiftUI
import QuickLook
import UIKit

struct FilePreviewView: View {
    let url: URL
    let lang: AppLanguage

    @Environment(\.dismiss) private var dismiss
    @State private var showingShare = false
    @State private var fileSizeBytes: Int64 = 0

    var body: some View {
        ZStack {
            ThemeStyle.bg.ignoresSafeArea()

            VStack(spacing: 12) {
                HStack(spacing: 12) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(ThemeStyle.textPrimary)
                            .frame(width: 36, height: 36)
                            .background(Color.white)
                            .clipShape(Circle())
                            .shadow(color: Color.black.opacity(0.06), radius: 4, y: 2)
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text(url.lastPathComponent)
                            .font(.subheadline.bold())
                            .foregroundColor(ThemeStyle.textPrimary)
                            .lineLimit(1)
                        Text("\(url.pathExtension.isEmpty ? "FILE" : url.pathExtension.uppercased()) · \(ByteCountFormatter.string(fromByteCount: fileSizeBytes, countStyle: .file))")
                            .font(.caption2.bold())
                            .foregroundColor(ThemeStyle.accent)
                    }

                    Spacer()

                    Button {
                        showingShare = true
                    } label: {
                        Image(systemName: "square.and.arrow.up")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(width: 36, height: 36)
                            .background(ThemeStyle.accent)
                            .clipShape(Circle())
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 14)

                QuickLookPreview(url: url)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                    .overlay(
                        RoundedRectangle(cornerRadius: 18)
                            .stroke(ThemeStyle.border, lineWidth: 1)
                    )
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16)
            }
        }
        .preferredColorScheme(.light)
        .onAppear {
            let attrs = try? FileManager.default.attributesOfItem(atPath: url.path)
            fileSizeBytes = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
        }
        .sheet(isPresented: $showingShare) {
            ShareSheet(url: url)
                .presentationDetents([.medium])
        }
    }
}

struct QuickLookPreview: UIViewControllerRepresentable {
    let url: URL

    func makeCoordinator() -> Coordinator {
        Coordinator(url: url)
    }

    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController()
        controller.dataSource = context.coordinator
        return controller
    }

    func updateUIViewController(_ controller: QLPreviewController, context: Context) {
        context.coordinator.url = url
        controller.reloadData()
    }

    class Coordinator: NSObject, QLPreviewControllerDataSource {
        var url: URL
        init(url: URL) { self.url = url }

        func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
            1
        }

        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
            url as NSURL
        }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
