import SwiftUI
import UniformTypeIdentifiers

/// iOS-safe App Data manager. It can only browse/write folders the user explicitly grants
/// through the Files document picker. It cannot inspect another app's private sandbox.
struct AppDataManagerView: View {
    let isKhmer: Bool

    @State private var selectedFolder: URL?
    @State private var folderItems: [URL] = []
    @State private var showingFolderPicker = false
    @State private var showingPatchPicker = false
    @State private var showingAlert = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    @State private var searchText = ""

    private var titleText: String { isKhmer ? "ទិន្នន័យ App" : "App Data Manager" }
    private var chooseFolderText: String { isKhmer ? "ជ្រើសរើស Folder របស់ App" : "Choose an App folder" }
    private var importPatchText: String { isKhmer ? "Import Patch (.3105)" : "Import Patch (.3105)" }
    private var noFolderText: String { isKhmer ? "មិនទាន់បានជ្រើសរើស Folder ទេ" : "No folder selected" }

    private var filteredItems: [URL] {
        guard !searchText.isEmpty else { return folderItems }
        return folderItems.filter { $0.lastPathComponent.localizedCaseInsensitiveContains(searchText) }
    }

    var body: some View {
        VStack(spacing: 14) {
            HStack {
                Text(titleText)
                    .font(.title3.bold())
                Spacer()
                Button { showingFolderPicker = true } label: {
                    Image(systemName: "folder.badge.plus")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.orange)
                        .frame(width: 42, height: 42)
                        .background(Color.orange.opacity(0.12))
                        .clipShape(Circle())
                }
                .accessibilityLabel(chooseFolderText)
            }
            .padding(.horizontal, 18)
            .padding(.top, 12)

            VStack(alignment: .leading, spacing: 8) {
                Label(selectedFolder?.lastPathComponent ?? noFolderText,
                      systemImage: "folder.fill")
                    .font(.headline)
                    .lineLimit(1)
                Text(isKhmer
                     ? "ជ្រើសរើស Folder តាម Files ដើម្បីផ្ដល់សិទ្ធិមើល និងដាក់ឯកសារ។"
                     : "Choose a folder in Files to grant access for browsing and importing.")
                    .font(.caption)
                    .foregroundColor(.secondary)
                Button { showingFolderPicker = true } label: {
                    Label(chooseFolderText, systemImage: "folder.open")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.orange)
                .disabled(false)
            }
            .padding(14)
            .background(Color(.secondarySystemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .padding(.horizontal, 16)

            Button { showingPatchPicker = true } label: {
                Label(importPatchText, systemImage: "square.and.arrow.down")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
            }
            .buttonStyle(.borderedProminent)
            .tint(.orange)
            .disabled(selectedFolder == nil)
            .padding(.horizontal, 16)

            // Always-visible compatibility table so users can see the deployment target.
            VStack(alignment: .leading, spacing: 10) {
                Label(isKhmer ? "តារាងជំនាន់ iOS ដែលអាចដំឡើងបាន" : "iOS Installation Compatibility",
                      systemImage: "iphone")
                    .font(.subheadline.bold())
                HStack {
                    Text(isKhmer ? "ជំនាន់ iOS" : "iOS Version")
                    Spacer()
                    Text(isKhmer ? "ស្ថានភាព" : "Status")
                }
                .font(.caption2.weight(.bold))
                .foregroundColor(.secondary)
                Divider()
                compatibilityRow("iOS 15 និងចាស់ជាងនេះ", isKhmer ? "មិនគាំទ្រ" : "Not supported")
                compatibilityRow("iOS 16", isKhmer ? "អប្បបរមាដែលបានកំណត់" : "Minimum deployment target")
                compatibilityRow("iOS 17–18", isKhmer ? "អាចត្រូវគ្នា · ត្រូវសាកល្បង" : "Target-compatible · test required")
                compatibilityRow("iOS 26 (រួមទាំង 26.4.1)", isKhmer ? "គាំទ្រតាម Deployment Target · អ្នកប្រើបញ្ជាក់ថាដំឡើងបាន" : "Supported by deployment target · user reports successful installation")
                compatibilityRow("iOS 27 Beta", isKhmer ? "មិនទាន់បញ្ជាក់" : "Unverified beta")
                Text(isKhmer
                     ? "Project កំណត់ iOS 16.0 ជាជំនាន់អប្បបរមា។ អ្នកប្រើបានបញ្ជាក់ថា iOS 26.4.1 អាចដំឡើងបាន។ ការដំណើរការមុខងារទាំងអស់នៅតែត្រូវសាកល្បងលើឧបករណ៍ពិត។"
                     : "The project deployment target is iOS 16.0. The user reports successful installation on iOS 26.4.1. Full feature behavior still needs testing on a real device.")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(14)
            .background(Color(.secondarySystemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .padding(.horizontal, 16)

            if selectedFolder != nil {
                HStack {
                    Image(systemName: "magnifyingglass").foregroundColor(.secondary)
                    TextField(isKhmer ? "ស្វែងរកឯកសារ..." : "Search files...", text: $searchText)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                .padding(11)
                .background(Color(.secondarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .padding(.horizontal, 16)

                if filteredItems.isEmpty {
                    VStack(spacing: 10) {
                        Image(systemName: "folder").font(.system(size: 34)).foregroundColor(.secondary)
                        Text(isKhmer ? "គ្មានឯកសារ" : "No files found").font(.headline)
                        Text(isKhmer ? "Folder នេះទទេ ឬមិនមានឯកសារដែលត្រូវគ្នា។" : "This folder is empty or has no matching files.")
                            .font(.caption).foregroundColor(.secondary).multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List(filteredItems, id: \.absoluteString) { url in
                        HStack(spacing: 12) {
                            Image(systemName: url.hasDirectoryPath ? "folder.fill" : "doc.fill")
                                .foregroundColor(.orange)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(url.lastPathComponent).lineLimit(1)
                                Text(url.pathExtension.isEmpty ? (isKhmer ? "Folder/ឯកសារ" : "Item") : url.pathExtension.uppercased())
                                    .font(.caption2).foregroundColor(.secondary)
                            }
                            Spacer()
                            if url.pathExtension.lowercased() == "3105" {
                                Text("PATCH").font(.caption2.bold()).foregroundColor(.orange)
                            }
                        }
                    }
                    .listStyle(.plain)
                }
            } else {
                Spacer()
                Text(isKhmer
                     ? "iPhone មិនអនុញ្ញាតឱ្យ App មួយចូលមើល Private Data របស់ App ផ្សេងដោយស្វ័យប្រវត្តិទេ។ អ្នកត្រូវជ្រើសរើស Folder ដែល App ឬ Files បានអនុញ្ញាត។"
                     : "iOS does not let one app automatically browse another app's private data. Select a folder that the app or Files has made available to you.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(22)
                Spacer()
            }
        }
        .background(Color(.systemBackground))
        .fileImporter(isPresented: $showingFolderPicker,
                      allowedContentTypes: [.folder],
                      allowsMultipleSelection: false) { result in
            handleFolderSelection(result)
        }
        .fileImporter(isPresented: $showingPatchPicker,
                      allowedContentTypes: [.data],
                      allowsMultipleSelection: false) { result in
            handlePatchSelection(result)
        }
        .alert(alertTitle, isPresented: $showingAlert) {
            Button(isKhmer ? "យល់ព្រម" : "OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
    }

    private func compatibilityRow(_ version: String, _ status: String) -> some View {
        HStack {
            Text(version).font(.caption.weight(.semibold))
            Spacer()
            Text(status).font(.caption).foregroundColor(.secondary)
        }
    }

    private func handleFolderSelection(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let folder = urls.first else { return }
            let access = folder.startAccessingSecurityScopedResource()
            defer { if access { folder.stopAccessingSecurityScopedResource() } }
            do {
                let values = try folder.resourceValues(forKeys: [.isDirectoryKey])
                guard values.isDirectory == true else {
                    showAlert(isKhmer ? "Folder មិនត្រឹមត្រូវ" : "Not a folder",
                              isKhmer ? "សូមជ្រើសរើស Folder មួយ។" : "Please choose a folder.")
                    return
                }
                selectedFolder = folder
                refreshFolderContents()
            } catch {
                showAlert(isKhmer ? "មិនអាចបើក Folder" : "Unable to open folder", error.localizedDescription)
            }
        case .failure(let error):
            showAlert(isKhmer ? "ជ្រើសរើសមិនបាន" : "Selection failed", error.localizedDescription)
        }
    }

    private func refreshFolderContents() {
        guard let folder = selectedFolder else { return }
        let access = folder.startAccessingSecurityScopedResource()
        defer { if access { folder.stopAccessingSecurityScopedResource() } }
        do {
            folderItems = try FileManager.default.contentsOfDirectory(
                at: folder,
                includingPropertiesForKeys: [.isDirectoryKey, .fileSizeKey],
                options: [.skipsHiddenFiles]
            ).sorted { $0.lastPathComponent.localizedCaseInsensitiveCompare($1.lastPathComponent) == .orderedAscending }
        } catch {
            folderItems = []
            showAlert(isKhmer ? "មើល Folder មិនបាន" : "Could not list folder", error.localizedDescription)
        }
    }

    private func handlePatchSelection(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let source = urls.first, let destinationFolder = selectedFolder else { return }
            guard source.pathExtension.lowercased() == "3105" else {
                showAlert("Invalid patch", isKhmer ? "សូមជ្រើសរើសឯកសារ .3105 ប៉ុណ្ណោះ។" : "Please choose a .3105 file.")
                return
            }
            let sourceAccess = source.startAccessingSecurityScopedResource()
            let destinationAccess = destinationFolder.startAccessingSecurityScopedResource()
            defer {
                if sourceAccess { source.stopAccessingSecurityScopedResource() }
                if destinationAccess { destinationFolder.stopAccessingSecurityScopedResource() }
            }
            do {
                let destination = destinationFolder.appendingPathComponent(source.lastPathComponent)
                if FileManager.default.fileExists(atPath: destination.path) {
                    showAlert(isKhmer ? "ឯកសារមានរួចហើយ" : "File already exists",
                              isKhmer ? "មានឯកសារឈ្មោះដូចគ្នានៅក្នុង Folder គោលដៅ។ សូមប្ដូរឈ្មោះមុននាំចូល។" : "A file with this name already exists. Rename it before importing.")
                    return
                }
                try FileManager.default.copyItem(at: source, to: destination)
                refreshFolderContents()
                showAlert(isKhmer ? "នាំចូលជោគជ័យ" : "Import complete",
                          isKhmer ? "បានចម្លងឯកសារ \(source.lastPathComponent) ទៅ Folder ដែលអ្នកបានជ្រើសរើស។" : "Copied \(source.lastPathComponent) into the folder you selected.")
            } catch {
                showAlert(isKhmer ? "នាំចូលមិនបាន" : "Import failed", error.localizedDescription)
            }
        case .failure(let error):
            showAlert(isKhmer ? "ជ្រើសរើសមិនបាន" : "Picker failed", error.localizedDescription)
        }
    }

    private func showAlert(_ title: String, _ message: String) {
        alertTitle = title
        alertMessage = message
        showingAlert = true
    }
}
