import SwiftUI

enum AppLanguage: String, CaseIterable, Identifiable {
    case khmer = "km"
    case english = "en"

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .khmer: return "ភាសាខ្មែរ"
        case .english: return "English"
        }
    }

    var subtitle: String {
        switch self {
        case .khmer: return "Khmer"
        case .english: return "English"
        }
    }
}

struct ThemeStyle {
    static let accent = Color(red: 0.85, green: 0.42, blue: 0.22)        // Warm orange/terracotta like 3105
    static let accentSoft = Color(red: 0.85, green: 0.42, blue: 0.22).opacity(0.12)
    static let bg = Color(red: 0.96, green: 0.96, blue: 0.97)            // Clean light gray
    static let card = Color.white
    static let textPrimary = Color(red: 0.11, green: 0.11, blue: 0.13)
    static let textSecondary = Color(red: 0.48, green: 0.48, blue: 0.52)
    static let border = Color.black.opacity(0.06)
    static let supportedGreen = Color(red: 0.16, green: 0.68, blue: 0.36)
}

struct L10n {
    let lang: AppLanguage

    func t(_ km: String, _ en: String) -> String {
        lang == .khmer ? km : en
    }

    // Tabs
    var tabHome: String { t("ទំព័រដើម", "Home") }
    var tabFiles: String { t("ឯកសារ", "Files") }
    var tabPatches: String { t("បាច់ហ្វាល", "Patches") }
    var tabCleaner: String { t("សម្អាត", "Cleaner") }

    // Onboarding
    var chooseLanguage: String { t("ជ្រើសរើសភាសា", "Choose your language") }
    var changeLater: String { t("អ្នកអាចប្តូរភាសានេះពេលក្រោយក្នុងការកំណត់", "You can change this later in Settings.") }
    var next: String { t("បន្ទាប់", "Next") }
    var back: String { t("ត្រឡប់", "Back") }
    var finish: String { t("ចាប់ផ្តើម", "Finish") }
    var welcomeTitle: String { t("សូមស្វាគមន៍មកកាន់ Saxzy Mod VIP", "Welcome to Saxzy Mod VIP") }
    var developedBy: String { t("បង្កើតដោយ Mg The God", "Developed by Mg The God") }
    var officialBadge: String { t("ផ្លូវការ · Mg The God", "Official Mg The God Identity") }
    var telegramJoinTitle: String { t("ភ្ជាប់ជាមួយ Telegram ផ្លូវការ", "Official Telegram Channel") }
    var telegramJoinDesc: String { t("ចូលរួម Channel @mgthegod68 ដើម្បីទទួលបានព័ត៌មានថ្មីៗ និងឯកសារអាប់ដេត", "Join @mgthegod68 for updates, configs, and support.") }
    var openTelegram: String { t("បើក Telegram @mgthegod68", "Open Telegram @mgthegod68") }

    // Home
    var deviceSection: String { t("ព័ត៌មានឧបករណ៍", "Device") }
    var hardwareModel: String { t("ម៉ូឌែលម៉ាស៊ីន", "Hardware model") }
    var iosVersion: String { t("ជំនាន់ iOS", "iOS Version") }
    var compatibility: String { t("ភាពត្រូវគ្នា", "Compatibility") }
    var supported: String { t("គាំទ្រ", "Supported") }
    var storageFree: String { t("ទំហំនៅសល់", "Free Storage") }
    var featuresSection: String { t("មុខងារ", "Features") }
    var featuresHint: String { t("បើក ឬបិទមុខងារសម្អាត ដើម្បីបង្ហាញនៅរបារខាងក្រោម", "Turn on Cleaner to show it in the app navigation.") }

    // Files
    var filesHeader: String { t("កម្មវិធីមើលឯកសារ", "File Browser") }
    var searchFiles: String { t("ស្វែងរកឯកសារ...", "Search files...") }
    var workspaceTitle: String { t("កន្លែងទុកឯកសារ Mg The God", "Mg The God Workspace") }
    var workspaceSub: String { t("ឯកសារ និងហ្វាល .3105 លើ iPhone របស់អ្នក", "Patches and files available in On My iPhone") }
    var noFilesYet: String { t("មិនទាន់មានឯកសារទេ", "No Files Yet") }
    var importHint: String { t("ចុចប៊ូតុង + ដើម្បីដាក់ឯកសារ ឬ .3105 ចូល", "Tap + to import files or .3105 packages.") }

    // Patches
    var patchesHeader: String { t("បាច់ហ្វាល", "Patches") }
    var searchPatches: String { t("ស្វែងរកបាច់ហ្វាល...", "Search patches") }
    var noPatchesTitle: String { t("មិនទាន់មានឯកសារ Patch ទេ", "No Patch Projects") }
    var noPatchesDesc: String { t("នាំចូលឯកសារ .3105 ដើម្បីគ្រប់គ្រងនៅទីនេះ", "Import a .3105 package to manage it here.") }
    var newPatch: String { t("នាំចូល Patch ថ្មី", "New Patch") }

    // Cleaner
    var cleanerHeader: String { t("សម្អាតប្រព័ន្ធ", "Cleaner") }
    var scanningCache: String { t("កំពុងស្កេនឯកសារ Cache...", "Scanning app caches...") }
    var readyToClean: String { t("រួចរាល់សម្រាប់សម្អាត", "Ready to clean") }
    var cleanNow: String { t("សម្អាតឥឡូវនេះ", "Clean Now") }
    var cacheFound: String { t("ទំហំ Cache ក្នុង App", "App Cache Size") }

    // Settings
    var settingsTitle: String { t("ការកំណត់", "Settings") }
    var done: String { t("រួចរាល់", "Done") }
    var languageTitle: String { t("ភាសា", "Language") }
    var socialMedia: String { t("បណ្តាញសង្គម", "Social media") }
    var telegramChannel: String { t("Telegram ផ្លូវការ (@mgthegod68)", "Official Telegram (@mgthegod68)") }
    var telegramSub: String { t("ចុចដើម្បីចូល Channel របស់ Mg The God", "Tap to join Mg The God channel") }
    var credits: String { t("អ្នកបង្កើត", "Credits") }
    var developerRole: String { t("អ្នកអភិវឌ្ឍន៍ និងរចនា", "Developer & Designer") }

    // Logs
    var sessionLogs: String { t("កំណត់ត្រាប្រព័ន្ធ", "Session Logs") }
    var clear: String { t("លុប", "Clear") }
}
