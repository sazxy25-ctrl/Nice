import SwiftUI

struct OnboardingView: View {
    @Binding var selectedLangRaw: String
    let onFinish: () -> Void

    @State private var step = 1
    private let telegramURL = URL(string: "https://t.me/mgthegod68")!

    private var lang: AppLanguage {
        AppLanguage(rawValue: selectedLangRaw) ?? .khmer
    }

    private var l: L10n { L10n(lang: lang) }

    var body: some View {
        ZStack {
            ThemeStyle.bg.ignoresSafeArea()

            VStack(spacing: 0) {
                // Top Step Indicator
                VStack(spacing: 8) {
                    HStack(spacing: 8) {
                        ForEach(1...3, id: \.self) { idx in
                            Capsule()
                                .fill(idx <= step ? ThemeStyle.accent : Color.black.opacity(0.12))
                                .frame(width: idx == step ? 28 : 18, height: 4)
                                .animation(.easeInOut(duration: 0.25), value: step)
                        }
                    }
                    Text(lang == .khmer ? "ជំហានទី \(step) នៃ 3" : "Step \(step) of 3")
                        .font(.caption)
                        .foregroundColor(ThemeStyle.textSecondary)
                }
                .padding(.top, 24)

                Spacer()

                if step == 1 {
                    stepLanguage
                } else if step == 2 {
                    stepWelcome
                } else {
                    stepTelegram
                }

                Spacer()

                // Bottom Navigation Buttons
                HStack(spacing: 12) {
                    if step > 1 {
                        Button {
                            withAnimation { step -= 1 }
                        } label: {
                            HStack(spacing: 4) {
                                Image(systemName: "chevron.left")
                                Text(l.back)
                            }
                            .font(.subheadline.bold())
                            .foregroundColor(ThemeStyle.accent)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                            .background(ThemeStyle.accentSoft)
                            .clipShape(Capsule())
                        }
                    }

                    Button {
                        if step < 3 {
                            withAnimation { step += 1 }
                        } else {
                            onFinish()
                        }
                    } label: {
                        HStack(spacing: 4) {
                            Text(step < 3 ? l.next : l.finish)
                            if step < 3 {
                                Image(systemName: "chevron.right")
                            }
                        }
                        .font(.subheadline.bold())
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(ThemeStyle.accent)
                        .clipShape(Capsule())
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 26)
            }
        }
        .preferredColorScheme(.light)
    }

    private var stepLanguage: some View {
        VStack(spacing: 22) {
            Image("LaunchLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 76, height: 76)
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .shadow(color: Color.black.opacity(0.08), radius: 8, y: 4)

            VStack(spacing: 6) {
                Text(l.chooseLanguage)
                    .font(.title2.bold())
                    .foregroundColor(ThemeStyle.textPrimary)
                Text(l.changeLater)
                    .font(.caption)
                    .foregroundColor(ThemeStyle.textSecondary)
            }

            VStack(spacing: 10) {
                ForEach(AppLanguage.allCases) { option in
                    let isSelected = option == lang
                    Button {
                        selectedLangRaw = option.rawValue
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(option.displayName)
                                    .font(.subheadline.bold())
                                    .foregroundColor(ThemeStyle.textPrimary)
                                Text(option.subtitle)
                                    .font(.caption2)
                                    .foregroundColor(ThemeStyle.textSecondary)
                            }
                            Spacer()
                            Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                                .font(.system(size: 20))
                                .foregroundColor(isSelected ? ThemeStyle.accent : Color.black.opacity(0.2))
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 14)
                        .background(isSelected ? ThemeStyle.accentSoft : Color.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(isSelected ? ThemeStyle.accent.opacity(0.4) : ThemeStyle.border, lineWidth: 1)
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                }
            }
            .padding(.horizontal, 22)
        }
    }

    private var stepWelcome: some View {
        VStack(spacing: 18) {
            Image("LaunchLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 84, height: 84)
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(ThemeStyle.accent.opacity(0.25), lineWidth: 1.5)
                )
                .shadow(color: Color.black.opacity(0.08), radius: 10, y: 4)

            VStack(spacing: 6) {
                Text(l.welcomeTitle)
                    .font(.title2.bold())
                    .foregroundColor(ThemeStyle.textPrimary)
                    .multilineTextAlignment(.center)
                Text(l.developedBy)
                    .font(.subheadline)
                    .foregroundColor(ThemeStyle.textSecondary)
            }

            HStack(spacing: 6) {
                Image(systemName: "checkmark.seal.fill")
                    .foregroundColor(ThemeStyle.accent)
                Text(l.officialBadge)
                    .font(.caption.bold())
                    .foregroundColor(ThemeStyle.textPrimary)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 8)
            .background(Color.white)
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(ThemeStyle.border, lineWidth: 1))
            .clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .padding(.horizontal, 24)
    }

    private var stepTelegram: some View {
        VStack(spacing: 18) {
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .fill(ThemeStyle.accentSoft)
                    .frame(width: 78, height: 78)
                Image(systemName: "paperplane.fill")
                    .font(.system(size: 34))
                    .foregroundColor(ThemeStyle.accent)
            }

            VStack(spacing: 6) {
                Text(l.telegramJoinTitle)
                    .font(.title3.bold())
                    .foregroundColor(ThemeStyle.textPrimary)
                Text(l.telegramJoinDesc)
                    .font(.caption)
                    .foregroundColor(ThemeStyle.textSecondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 28)
            }

            Button {
                UIApplication.shared.open(telegramURL)
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "paperplane.fill")
                    Text(l.openTelegram)
                }
                .font(.subheadline.bold())
                .foregroundColor(ThemeStyle.accent)
                .padding(.horizontal, 20)
                .padding(.vertical, 12)
                .background(Color.white)
                .overlay(Capsule().stroke(ThemeStyle.accent.opacity(0.35), lineWidth: 1))
                .clipShape(Capsule())
                .shadow(color: Color.black.opacity(0.04), radius: 6, y: 2)
            }
        }
    }
}
