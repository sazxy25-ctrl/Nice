import SwiftUI
import CryptoKit
import Security

struct PasswordGateView: View {
    let isSetup: Bool
    let onSuccess: () -> Void

    @State private var password = ""
    @State private var confirmation = ""
    @State private var errorText = ""

    private var titleText: String { isSetup ? "Create Password" : "Enter Password" }

    var body: some View {
        VStack(spacing: 18) {
            Spacer()
            Image("LaunchLogo")
                .resizable().scaledToFit().frame(width: 92, height: 92)
                .clipShape(RoundedRectangle(cornerRadius: 22))
            Text("Saxzy Mod VIP")
                .font(.largeTitle.bold())
            Text(titleText).font(.headline).foregroundColor(.secondary)
            SecureField("Password", text: $password)
                .textContentType(isSetup ? .newPassword : .password)
                .textFieldStyle(.roundedBorder)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            if isSetup {
                SecureField("Confirm password", text: $confirmation)
                    .textContentType(.newPassword)
                    .textFieldStyle(.roundedBorder)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }
            if !errorText.isEmpty {
                Text(errorText).font(.footnote).foregroundColor(.red)
            }
            Button(action: submit) {
                Text(isSetup ? "Save Password" : "Unlock")
                    .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 13)
            }
            .buttonStyle(.borderedProminent).tint(.orange)
            .disabled(password.isEmpty || (isSetup && confirmation.isEmpty))
            Spacer()
            Text("Your password hash is stored in the iOS Keychain.")
                .font(.caption2).foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(28)
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
    }

    private func submit() {
        let hash = SHA256.hash(data: Data(password.utf8)).map { String(format: "%02x", $0) }.joined()
        if isSetup {
            guard password.count >= 6 else { errorText = "Use at least 6 characters."; return }
            guard password == confirmation else { errorText = "Passwords do not match."; return }
            guard KeychainPassword.save(hash: hash) else { errorText = "Could not save password to Keychain."; return }
            onSuccess()
        } else {
            guard let savedHash = KeychainPassword.read(), savedHash == hash else {
                errorText = "Incorrect password. Try again."
                password = ""
                return
            }
            onSuccess()
        }
    }
}

private enum KeychainPassword {
    private static let service = "com.saxzymodvip.app.password"
    private static let account = "password-hash"

    static func save(hash: String) -> Bool {
        let data = Data(hash.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: data
        ]
        SecItemDelete(query as CFDictionary)
        return SecItemAdd(query as CFDictionary, nil) == errSecSuccess
    }

    static func read() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
}
