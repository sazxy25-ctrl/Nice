# Saxzy Mod VIP — refreshed source project

This project is an iOS SwiftUI app targeting **iOS 16.0 and later**. The target is a build setting, not a guarantee that every later iOS release or beta has been tested.

## What changed

- Added an **App Data** tab.
- The user chooses a folder using the native iOS Files folder picker.
- The app lists the files and subfolders inside the folder the user explicitly granted access to.
- The user can select a `.3105` file from Files and copy it into that selected folder.
- Existing same-name files are not overwritten; the user gets a clear error instead.
- The GitHub Actions workflow now builds the source checked out in the repository root. It no longer tries to unzip an old `SaxzyModVIP_IPA_Builder-v7.zip`, which could silently build stale code.

## Important iOS sandbox limitation

This is **not** a jailbreak tool. iOS does not allow an ordinary third-party app to enumerate every installed app's private container or write into another app's private `Documents`, `Library`, or database folders. The new feature only reads/writes folders that the user explicitly selects in Files and that iOS grants access to. If another app does not expose a folder through Files / document sharing, Saxzy Mod VIP cannot reach its private data.

The `.3105` file is copied as a file. This project does not decrypt, parse, or apply proprietary patch instructions inside `.3105` to another app. That would require a documented format and a supported import interface from the target app.

## Build using GitHub Actions

1. Upload **the contents of this ZIP** to the root of your GitHub repository (including `.github/workflows/build-ipa.yml`). Do not put the whole ZIP inside the repository and expect the workflow to unzip it.
2. Commit the files to `main` (or `master`).
3. Open the repository's **Actions** tab.
4. Select **Build Saxzy Mod VIP Unsigned IPA** and press **Run workflow** (or wait for a push build).
5. When the run succeeds, open the run and download the artifact named `SaxzyModVIP-unsigned-ipa`.
6. Sign the unsigned IPA with your own signing method before installing. ESign cannot compile source code; it only signs/installs a built IPA.

## Signing and safety

- Do not put Apple ID passwords, `.p12` passwords, private keys, or provisioning profiles in chat.
- The generated IPA is unsigned. It is not installable until signed with a valid certificate/provisioning setup.
- The source has not been compiled on an Apple Xcode runner in this environment. The GitHub Actions run is the authoritative compile check; if it fails, share the full build log so the exact error can be fixed.

## Compatibility

| iOS | Project setting / status |
|---|---|
| iOS 15 | Not supported by this project (deployment target is 16.0) |
| iOS 16+ | Deployment target supports installation; test app behavior on each device |
| Newer releases / betas | Not verified until built and tested on those versions |

## First-run password

After the existing welcome/onboarding screen, the app asks the user to create a password (minimum 6 characters) and confirm it. On later launches it asks for the password again. Only a SHA-256 password hash is stored in the iOS Keychain; no previously shared chat password is embedded in the source.


## iOS installation compatibility table

The App Data screen now shows an always-visible iOS compatibility table. The XcodeGen project sets iOS 16.0 as the minimum deployment target. iOS 15 and earlier are not supported by this project configuration. The user reports that installation works on iOS 26.4.1. This is a user-reported installation result; full feature behavior still needs testing. Beta compatibility is not guaranteed. The table is a deployment-target guide, not a claim that every version has been tested.
